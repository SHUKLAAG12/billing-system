#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "transaction.h"

void saveTransaction(struct Transaction *transaction) {
    FILE *file = fopen(TRANSACTION_FILE, "a");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    fprintf(file, "Customer ID: %s\n", transaction->customer.customer_id);
    fprintf(file, "Name: %s\n", transaction->customer.name);
    fprintf(file, "Address: %s\n", transaction->customer.address);
    fprintf(file, "Date and Time: %s", asctime(localtime(&transaction->dateTime)));
    fprintf(file, "Total Amount: Rs%.2f\n", transaction->totalAmount);
    fprintf(file, "Items Purchased:\n");

    for (int i = 0; i < transaction->itemCount; i++) {
        fprintf(file, "%d. %s - Quantity: %d, Price: Rs%.2f\n", i + 1, transaction->items[i].name, transaction->items[i].quantity, transaction->items[i].price);
    }
    fprintf(file, "-----------------------------------------\n");
    fclose(file);

    printf("\nTransaction saved successfully.\n");
}

void searchTransactions(char customerId[]) {
    FILE *file = fopen(TRANSACTION_FILE, "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    char line[256];
    int found = 0;

    while (fgets(line, sizeof(line), file)) {
        if (strstr(line, customerId)) {
            found = 1;
            printf("\n%s", line);
            while (fgets(line, sizeof(line), file) && strcmp(line, "-----------------------------------------\n") != 0) {
                printf("%s", line);
            }
            printf("%s", line); // Print the separator line
        }
    }

    if (!found) {
        printf("No transactions found for Customer ID: %s\n", customerId);
    }

    fclose(file);
}
