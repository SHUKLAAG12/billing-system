#ifndef TRANSACTION_H
#define TRANSACTION_H

#include "customer.h"
#include<time.h>

#define MAX_ITEMS 10
#define MAX_ITEM_NAME_LENGTH 50
#define TRANSACTION_FILE "transactions.txt"

struct Item {
    char name[MAX_ITEM_NAME_LENGTH];
    double price;
    int quantity;
};

struct Transaction {
    struct Customer customer;
    struct Item items[MAX_ITEMS];
    int itemCount;
    double totalAmount;
    time_t dateTime;
};

void saveTransaction(struct Transaction *transaction);
void searchTransactions(char customerId[]);

#endif // TRANSACTION_H
