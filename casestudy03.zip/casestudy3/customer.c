#include <stdio.h>
#include <string.h>
#include "customer.h"

void inputCustomerDetails(struct Customer *customer) {
    printf("\nEnter customer name: ");
    getchar(); // To consume the newline left by the previous input
    fgets(customer->name, sizeof(customer->name), stdin);
    customer->name[strcspn(customer->name, "\n")] = 0;

    printf("Enter customer address: ");
    fgets(customer->address, sizeof(customer->address), stdin);
    customer->address[strcspn(customer->address, "\n")] = 0;

    printf("Enter customer ID: ");
    fgets(customer->customer_id, sizeof(customer->customer_id), stdin);
    customer->customer_id[strcspn(customer->customer_id, "\n")] = 0;
}
