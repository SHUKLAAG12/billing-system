#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "auth.h"
#include "customer.h"
#include "billing.h"
#include "transaction.h"

int main() {
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];

    printf("Welcome to the Billing System\n");
    printf("Enter your username: ");
    fgets(username, MAX_USERNAME_LENGTH, stdin);
    username[strcspn(username, "\n")] = 0;

    printf("Enter your password: ");
    fgets(password, MAX_PASSWORD_LENGTH, stdin);
    password[strcspn(password, "\n")] = 0;

    if (authenticate(username, password)) {
        printf("Login successful. Welcome, %s!\n", username);

        int initialChoice;
        printf("\nChoose an option:\n");
        printf("1. Search Transactions\n");
        printf("2. Proceed with Billing\n");
        printf("Enter your choice (1-2): ");
        scanf("%d", &initialChoice);

        if (initialChoice == 1) {
            printf("\nEnter the Customer ID to search: ");
            char searchId[10];
            scanf("%s", searchId);
            searchTransactions(searchId);
        } else if (initialChoice == 2) {
            struct Customer customer;
            inputCustomerDetails(&customer);

            struct Transaction transaction;
            transaction.customer = customer;
            transaction.itemCount = 0;
            transaction.totalAmount = 0.0;
            transaction.dateTime = time(NULL);

            int choice, quantity;
            do {
                displayMenu();
                printf("Enter your choice (1-12): ");
                scanf("%d", &choice);

                if (choice >= 1 && choice <= 10) {
                    printf("Enter the quantity: ");
                    scanf("%d", &quantity);
                    addToBill(&transaction, choice, quantity);
                } else if (choice == 12) {
                    printf("\nEnter the Customer ID to search: ");
                    char searchId[10];
                    scanf("%s", searchId);
                    searchTransactions(searchId);
                    break; // Exit the loop after searching for transactions
                } else if (choice != 11) {
                    printf("\nInvalid choice. Please try again.\n");
                }
            } while (choice != 11);

            if (choice != 12) { // Avoid showing this if option 12 was chosen
                printf("\n\nCustomer Information:\n");
                printf("Name: %s\n", transaction.customer.name);
                printf("Address: %s\n", transaction.customer.address);
                printf("Customer ID: %s\n", transaction.customer.customer_id);
                printf("\nDate and Time of Purchase: %s", asctime(localtime(&transaction.dateTime)));
                printf("\n**\n");
                printf("\nItems Purchased:\n");
                for (int i = 0; i < transaction.itemCount; i++) {
                    printf("%d. %s - Quantity : %d\n", i + 1, transaction.items[i].name, transaction.items[i].quantity);
                }
                printf("\nTotal Amount: Rs%.2f\n", transaction.totalAmount);

                saveTransaction(&transaction);
            }
        } else {
            printf("Invalid choice. Exiting...\n");
        }
    } else {
        printf("Invalid username or password. Please try again.\n");
    }

    return 0;
}