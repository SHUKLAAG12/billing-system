#ifndef CUSTOMER_H
#define CUSTOMER_H

struct Customer {
    char name[50];
    char address[100];
    char customer_id[10];
};

void inputCustomerDetails(struct Customer *customer);

#endif // CUSTOMER_H
