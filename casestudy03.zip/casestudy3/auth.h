#ifndef AUTH_H
#define AUTH_H

#define MAX_USERNAME_LENGTH 20
#define MAX_PASSWORD_LENGTH 20

int authenticate(char username[], char password[]);

#endif // AUTH_H
