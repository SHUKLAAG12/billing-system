#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "billing.h"

void displayMenu() {
    printf("\n\n**************** MENU ****************\n");
    printf("1. Chocolates - Rs10\n");
    printf("2. Pens       - Rs15\n");
    printf("3. Pencils    - Rs20\n");
    printf("4. Soaps      - Rs34.08\n");
    printf("5. Maggie     - Rs22\n");
    printf("6. Chips      - Rs33.55\n");
    printf("7. Ice cream  - Rs50\n");
    printf("8. Juices     - Rs55\n");
    printf("9. Brush      - Rs11.18\n");
    printf("10. Cupcake   - Rs40.45\n");
    printf("11. Exit\n");
    printf("12. Search Transactions by Customer ID\n");
}

float getPrice(int choice) {
    switch (choice) {
        case 1: return 10.0;
        case 2: return 15.0;
        case 3: return 20.0;
        case 4: return 34.08;
        case 5: return 22.0;
        case 6: return 33.55;
        case 7: return 50.0;
        case 8: return 55.0;
        case 9: return 11.18;
        case 10: return 40.45;
        default: return 0.0;
    }
}

void addToBill(struct Transaction *transaction, int choice, int quantity) {
    if (transaction->itemCount < MAX_ITEMS) {
        struct Item item;
        switch (choice) {
            case 1: strcpy(item.name, "Chocolates"); break;
            case 2: strcpy(item.name, "Pens"); break;
            case 3: strcpy(item.name, "Pencils"); break;
            case 4: strcpy(item.name, "Soaps"); break;
            case 5: strcpy(item.name, "Maggie"); break;
            case 6: strcpy(item.name, "Chips"); break;
            case 7: strcpy(item.name, "Ice cream"); break;
            case 8: strcpy(item.name, "Juices"); break;
            case 9: strcpy(item.name, "Brush"); break;
            case 10: strcpy(item.name, "Cupcake"); break;
            default: return;
        }
        item.price = getPrice(choice);
        item.quantity = quantity;

        transaction->items[transaction->itemCount++] = item;
        transaction->totalAmount += (item.price * quantity);

        printf("\n%s (Quantity: %d) added to the bill.\n", item.name, quantity);
    } else {
        printf("\nMaximum items reached. Cannot add more.\n");
    }
}
