#ifndef BILLING_H
#define BILLING_H

#include "transaction.h"

void displayMenu();
float getPrice(int choice);
void addToBill(struct Transaction *transaction, int choice, int quantity);

#endif // BILLING_H
