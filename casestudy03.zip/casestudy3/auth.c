
#include <string.h>
#include "auth.h"

int authenticate(char username[], char password[]) {
    char correctUsername[] = "admin";
    char correctPassword[] = "admin123";

    if (strcmp(username, correctUsername) == 0 && strcmp(password, correctPassword) == 0) {
        return 1;
    } else {
        return 0;
    }
}