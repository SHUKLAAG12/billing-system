#include <stdio.h>
#include "c2.c"
#include "c1.c"

int main() {
    char customerName[50];
    char customerAddress[100];
    char customerid[10];
    int choice;
    float total = 0.0;

    
    inputCustomerDetails(customerName, customerAddress,customerid);
    displayCustomerDetails(customerName, customerAddress, customerid);

    
    do {
        displayMenu();
        printf("Enter your choice (1-11): ");
        scanf("%d", &choice);

        if (choice >= 1 && choice <= 10) {
            total += getPrice(choice);
            printf("\nItem added to bill.\n");
        } else if (choice != 11) {
            printf("\nInvalid choice. Please try again.\n");
        }
    } while (choice != 11);

    // Display total bill
    
    printf("Total bill: Rs%.2f\n", total);

    return 0;
}
