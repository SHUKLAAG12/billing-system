#include <stdio.h>

void displayMenu() {
    printf("\n\n**************** MENU ****************\n");
    printf("1. Chocolates - Rs10\n");
    printf("2. Pens       - Rs15\n");
    printf("3. Pencils    - Rs20\n");
    printf("4. Soaps      - Rs34.08\n");
    printf("5. Maggie     - Rs22\n");
    printf("6. Chips      - Rs33.55\n");
    printf("7. Ice cream  - Rs50\n");
    printf("8. Jucies     - Rs55\n");
    printf("9. Brush      - Rs11.18\n");
    printf("10. Cupcake   - Rs40.45 \n");
    printf("11. Exit\n ");
}

float getPrice(int choice) {
    switch (choice) {
        case 1:
            printf("You have selected Chocolate");
            return 10.0;
        case 2:
            printf("You have selected Pens");
            return 15.0;
        case 3:
            printf("You have selected Pencils");
            return 20.0;
        case 4:
            printf("You have selected Soaps");
            return 34.08;
        case 5:
            printf("You have selected Maggie");
            return 22.0;
        case 6:
            printf("You have selected Chips");
            return 33.55;
        case 7:
            printf("You have selected Ice cream");
            return 50.0;
        case 8:
             printf("You have selected Jucies ");
            return 55.0;
        case 9:
             printf("You have selected Brushes");
            return 11.18;
        case 10:
             printf("You have selected Cup cakes");
            return 40.45; 
        default:
            return 0.0;
    }
}
