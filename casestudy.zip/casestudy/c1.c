#include <stdio.h>
#include<time.h>

void inputCustomerDetails(char *name, char *address, char *customer_id) {
    printf("Enter customer name: ");
    scanf("%s", name);
    printf("Enter customer address: ");
    scanf("%s", address);
    printf("Enter the customer id: ");
    scanf("%s" , customer_id); 
    
}

void displayCustomerDetails(char *name, char *address, char *customer_id) {
    printf("\nCustomer Details:\n");
    printf("Name: %s\n", name);
    printf("Address: %s\n", address);
    printf("Customer id: %s\n",customer_id);
    time_t rawtime;
    struct tm *timeinfo;

    time(&rawtime);
    timeinfo = localtime(&rawtime);
 printf("Current time and date: %s", asctime(timeinfo));
    
    
}
